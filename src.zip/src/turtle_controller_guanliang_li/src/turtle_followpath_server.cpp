#include "rclcpp/rclcpp.hpp"                         // ROS2 C++接口库
#include "turtle_controller_interfaces/srv/follow_path.hpp"    // 自定义的服务接口

#include "turtlesim/srv/teleport_absolute.hpp"
#include "turtlesim/msg/pose.hpp"
#include "geometry_msgs/msg/twist.hpp"
#define M_PI       3.14159265358979323846   // pi

#include <cmath>
#include <vector>
#include <iostream>

using std::placeholders::_1;
using std::placeholders::_2;

class followpathServer : public rclcpp::Node{
    public: 
    followpathServer() : Node("followpathServer"){
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Let's go.");
        RCLCPP_INFO(this->get_logger(), "I am a cute turtle. I want to go to several points (x, y) at speed. Please input these parameters.");
        callback_group = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
        // server
        server_ = this->create_service<turtle_controller_interfaces::srv::FollowPath>("follow_path", 
            std::bind(&followpathServer::followpathServer_callback, this, std::placeholders::_1, std::placeholders::_2),
            rmw_qos_profile_services_default,callback_group);
        sub_ = this->create_subscription<turtlesim::msg::Pose>("/turtle1/pose", 10, std::bind(&followpathServer::pose_cb,this,std::placeholders::_1));
        cmd_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
    }
    private:
    void followpathServer_callback(const std::shared_ptr<turtle_controller_interfaces::srv::FollowPath::Request> request, 
                   const std::shared_ptr<turtle_controller_interfaces::srv::FollowPath::Response> response)
    {
        // 完成加法求和计算，将结果放到反馈的数据中
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "I'm coming~~~~");

        std::vector<float> target_x_array(request->x_array.begin(), request->x_array.end());
        std::vector<float> target_y_array(request->y_array.begin(), request->y_array.end());
        float speed = request->speed;
        int input_num = target_x_array.size();
        int omega_flag = 1;

        rclcpp::Rate rate(100); // 设置检查频率，这里每秒检查10次
        geometry_msgs::msg::Twist velocity_command;

        double dis_delta;

        for (int i = 0; i < input_num; ++i){
            double target_x = target_x_array[i];
            double target_y = target_y_array[i];
            double distance = std::sqrt(std::pow((target_x - x), 2) + std::pow((target_y - y), 2));
            double angle_to_target = std::atan2((target_y - y), (target_x - x));
            if (i == 0){
                double alpha;
                if(angle_to_target >= 0 && angle_to_target < M_PI/2){
                    alpha = angle_to_target; // 1
                }else if(angle_to_target >= M_PI/2){
                    alpha = M_PI - angle_to_target; // 2
                    speed = -speed;
                    omega_flag = -1;
                }else if(angle_to_target < 0 && angle_to_target >= -M_PI/2){
                    alpha = -angle_to_target; // 4
                    omega_flag = -1;
                }else{
                    alpha = M_PI + angle_to_target; // 3
                    speed = -speed;
                }
                double r = distance/2/cos(M_PI/2-alpha);
                double omega = speed/r*omega_flag;            // angle_velocity_z

                // give command
                velocity_command.linear.x = speed;
                velocity_command.angular.z = omega;
            }else{
                std::vector<double> vector1;
                std::vector<double> vector2;
                std::vector<double> vector3;
                vector1.push_back(target_x-x);
                vector1.push_back(target_y-y);
                double beta;
                if(theta >= 0 && theta < M_PI/2){
                    beta = theta + M_PI/2; // 1
                }else if(theta >= M_PI/2){
                    beta = theta - M_PI/2; // 2
                }else if(theta < 0 && theta >= -M_PI/2){
                    beta = theta + M_PI/2; // 4
                }else{
                    beta = -theta - M_PI/2; // 3
                }
                vector2.push_back(cos(beta));
                vector2.push_back(sin(beta));
                vector3.push_back(cos(theta));
                vector3.push_back(sin(theta));
                double dot_product = vector1[0] * vector2[0] + vector1[1] * vector2[1];
                double magnitude1 = std::sqrt(vector1[0] * vector1[0] + vector1[1] * vector1[1]);
                double magnitude2 = std::sqrt(vector2[0] * vector2[0] + vector2[1] * vector2[1]);
                double angle_radians = std::acos(dot_product / (magnitude1 * magnitude2));
                if(angle_radians > M_PI/2){
                    angle_radians = M_PI - angle_radians;
                }
                
                double r;
                if(abs(abs(theta)-M_PI/2) <= 0.00001){
                    if(target_x > x && theta > 0){
                        omega_flag = -1;
                    }
                    if(target_x < x && theta < 0){
                        omega_flag = -1;
                    }
                    if (abs(target_y-y) < 0.01){
                        r = abs(target_x-x)/2;
                    }else{
                        r = distance/2/cos(angle_radians);
                    }
                    
                }else{
                    r = distance/2/cos(angle_radians);
                    double c1 = -tan(theta)*x+y;
                    double c2 = -tan(theta)*target_x+target_y;
                    if(abs(c1-c2) < 0.1){
                        omega_flag = 0;
                    }
                    // else if(c1 < c2){
                    //     double dot_product1 = vector1[0] * vector3[0] + vector1[1] * vector3[1];
                    //     double magnitude11 = std::sqrt(vector1[0] * vector1[0] + vector1[1] * vector1[1]);
                    //     double magnitude21 = std::sqrt(vector3[0] * vector3[0] + vector3[1] * vector3[1]);
                    //     double angle_radians1 = std::acos(dot_product1 / (magnitude11 * magnitude21));
                    //     if (angle_radians1 > M_PI/2){
                    //         omega_flag = -1;
                    //     }
                    //     if (tan(theta) < 0){
                    //         omega_flag = -1*omega_flag;
                    //     }

                    // }
                    // else{
                    //     double dot_product1 = vector1[0] * vector3[0] + vector1[1] * vector3[1];
                    //     double magnitude11 = std::sqrt(vector1[0] * vector1[0] + vector1[1] * vector1[1]);
                    //     double magnitude21 = std::sqrt(vector3[0] * vector3[0] + vector3[1] * vector3[1]);
                    //     double angle_radians1 = std::acos(dot_product1 / (magnitude11 * magnitude21));
                    //     if (angle_radians1 < M_PI/2){
                    //         omega_flag = -1;
                    //     }
                    // }
                    else{
                        double cha_product = vector3[0] * vector1[1] - vector3[1] * vector1[0];
                        if(cha_product <= 0){
                            omega_flag = -1;
                        }
                    }
                }
                double omega = speed/r*omega_flag;            // angle_velocity_z
                velocity_command.angular.z = omega;
            }
            omega_flag = 1;
            rclcpp::Rate rate(10); // 设置检查频率，这里每秒检查10次
            while (true){

                distance = std::sqrt(std::pow((target_x - x), 2) + std::pow((target_y - y), 2));
                RCLCPP_INFO(this->get_logger(), "distance: %f", distance);
                cmd_pub_->publish(velocity_command);

                double x_fore = x+speed*cos(theta)*0.01;
                double y_fore = y+speed*sin(theta)*0.01;
                double distance_fore = std::sqrt(std::pow((target_x - x_fore), 2) + std::pow((target_y - y_fore), 2));

                if (distance < distance_fore && distance < 0.5){
                    RCLCPP_INFO(this->get_logger(), "I will go to next point.");
                    RCLCPP_INFO(this->get_logger(), "After movement, turtle current position - x: %f, y: %f", x, y);
                    break;
                }

                rate.sleep();
            }
            dis_delta = distance;
        }
        
        if (dis_delta < 0.1){
            response->move_result = 1;
        }else{
            response->move_result = 0;
        }
        RCLCPP_INFO(this->get_logger(), "After movement, turtle current position - x: %f, y: %f", x, y);
        // RCLCPP_INFO(this->get_logger(), "After movement, turtle current position - x: %f, y: %f", x, y);
        
        // 输出日志信息，提示已经完成加法求和计算                                                    
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Incoming request\na: %ld" " b: %ld",             
        //             request->a, request->b);
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "sending back response: [%ld]", (long int)response->sum);
    }
    private:
    rclcpp::Service<turtle_controller_interfaces::srv::FollowPath>::SharedPtr server_;
    rclcpp::CallbackGroup::SharedPtr callback_group;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr sub_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
    float x,y,theta;
    void pose_cb(const turtlesim::msg::Pose::SharedPtr pose)
    {
        x = pose->x;
        y = pose->y;
        theta = pose->theta;
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "%f",x);
    }
};

// float x_pos,y_pose,theta_pose;

// void gotoServer(const std::shared_ptr<turtle_controller_interfaces::srv::Goto::Request> request, 
//         std::shared_ptr<turtle_controller_interfaces::srv::Goto::Response>      response)
// {
//     RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Let's go!");
//     response->move_result = 1;
//     rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr sub_;
//     rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
//     // sub_ = create_subscription<turtlesim::msg::Pose>("/turtle1/pose", 10, std::bind(&gotoServer::pose_cb,this,std::placeholders::_1));
//     // cmd_pub_ = create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
// }

// ROS2节点主入口main函数
int main(int argc, char **argv)                                                                 
{
    // ROS2 C++接口初始化
    // rclcpp::init(argc, argv);
    // // 创建ROS2节点对象并进行初始化                                                                   
    // std::shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("gotoServer");   
    // // 创建服务器对象（接口类型、服务名、服务器回调函数）  
    // rclcpp::Service<turtle_controller_interfaces::srv::Goto>::SharedPtr service =
    //     node->create_service<turtle_controller_interfaces::srv::Goto>("goto", &gotoServer);
          
    // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Ready to move.");

    // // 循环等待ROS2退出
    // rclcpp::spin(node);    
    // // 关闭ROS2 C++接口                                                                     
    // rclcpp::shutdown();

    rclcpp::init(argc, argv);
    auto node = std::make_shared<followpathServer>();
    // 把节点的执行器变成多线程执行器, 避免死锁
    rclcpp::executors::MultiThreadedExecutor exector;
    exector.add_node(node);
    exector.spin();
    rclcpp::shutdown();

    return 0;                                          
}