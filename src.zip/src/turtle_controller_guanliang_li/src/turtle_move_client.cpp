#include "rclcpp/rclcpp.hpp"                          // ROS2 C++接口库
#include "turtle_controller_interfaces/srv/goto.hpp"    // 自定义的服务接口
#include "turtle_controller_interfaces/srv/follow_path.hpp"    // 自定义的服务接口

#include <chrono>
#include <cstdlib>
#include <memory>
#include <vector>

using namespace std::chrono_literals;

int main(int argc, char **argv)
{
    // ROS2 C++接口初始化
    rclcpp::init(argc, argv);                      

    if (argc < 4) {
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "usage: turtle_move_client X Y SPEED or X_array Y_array SPEED");
        return 1;
    }

    // 创建ROS2节点对象并进行初始化
    std::shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("turtle_move_client");  

    if (argc == 4) {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "goto");
    // 创建服务客户端对象（服务接口类型，服务名） 
    rclcpp::Client<turtle_controller_interfaces::srv::Goto>::SharedPtr client =
        node->create_client<turtle_controller_interfaces::srv::Goto>("goto");       

    // 创建服务接口数据
    auto request = std::make_shared<turtle_controller_interfaces::srv::Goto::Request>();   
    request->x = atof(argv[1]);
    request->y = atof(argv[2]);
    request->speed = atof(argv[3]);

    while (!client->wait_for_service(1s)) {                                                   
       if (!rclcpp::ok()) {
           RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Interrupted while waiting for the service. Exiting.");
           return 0;
       }
       RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "service not available, waiting again...");
    }

    auto result = client->async_send_request(request);  

    if (rclcpp::spin_until_future_complete(node, result) ==
        rclcpp::FutureReturnCode::SUCCESS)                                                    
    {
        // 将收到的反馈信息打印输出
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Success (1) or not (0): %ld", result.get()->move_result);             
    } else {
        RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to move the turtle");
    }

    } else {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "movepath");
    rclcpp::Client<turtle_controller_interfaces::srv::FollowPath>::SharedPtr client =
        node->create_client<turtle_controller_interfaces::srv::FollowPath>("follow_path");             

    // 创建服务接口数据
    auto request = std::make_shared<turtle_controller_interfaces::srv::FollowPath::Request>();
    std::vector<float> x_vector;
    std::vector<float> y_vector;
    int input_num = argc;

    for (int i = 1; i <= (input_num-2)/2; ++i){
        x_vector.push_back(static_cast<float>(atof(argv[i])));
    }
    for (int i = input_num/2; i < input_num-1; ++i){
        y_vector.push_back(static_cast<float>(atof(argv[i])));
    }

    float speed_tmp = atof(argv[input_num-1]);
    request->x_array = x_vector;
    request->y_array = y_vector;
    request->speed = speed_tmp;

    while (!client->wait_for_service(1s)) {                                                   
       if (!rclcpp::ok()) {
           RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Interrupted while waiting for the service. Exiting.");
           return 0;
       }
       RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "service not available, waiting again...");
    }

    auto result = client->async_send_request(request); 
    if (rclcpp::spin_until_future_complete(node, result) ==
        rclcpp::FutureReturnCode::SUCCESS)                                                    
    {
        // 将收到的反馈信息打印输出
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Success (1) or not (0): %ld", result.get()->move_result);  
    } else {
        RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to move the turtle");
    }

    }
    rclcpp::shutdown();  
    return 0;
}
