#include "rclcpp/rclcpp.hpp"                         // ROS2 C++接口库
#include "turtle_controller_interfaces/srv/goto.hpp"    // 自定义的服务接口

#include "turtlesim/srv/teleport_absolute.hpp"
#include "turtlesim/msg/pose.hpp"
#include "geometry_msgs/msg/twist.hpp"
#define M_PI       3.14159265358979323846   // pi

#include <cmath>

using std::placeholders::_1;
using std::placeholders::_2;

class gotoServer : public rclcpp::Node{
    public: 
    gotoServer() : Node("gotoServer"){
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Let's go.");
        RCLCPP_INFO(this->get_logger(), "I am a cute turtle. I want to go to point (x, y) at speed. Please input these parameters.");
        callback_group = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
        // server
        server_ = this->create_service<turtle_controller_interfaces::srv::Goto>("goto", 
            std::bind(&gotoServer::gotoServer_callback, this, std::placeholders::_1, std::placeholders::_2),
            rmw_qos_profile_services_default,callback_group);
        sub_ = this->create_subscription<turtlesim::msg::Pose>("/turtle1/pose", 10, std::bind(&gotoServer::pose_cb,this,std::placeholders::_1));
        cmd_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
    }
    private:
    void gotoServer_callback(const std::shared_ptr<turtle_controller_interfaces::srv::Goto::Request> request, 
                   const std::shared_ptr<turtle_controller_interfaces::srv::Goto::Response> response)
    {
        // 完成加法求和计算，将结果放到反馈的数据中
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "I'm coming~~~~");

        float target_x = request->x;
        float target_y = request->y;
        float speed = request->speed;
        int omega_flag = 1;
        
        // calculate distance
        double distance = std::sqrt(std::pow((target_x - x), 2) + std::pow((target_y - y), 2));
        double angle_to_target = std::atan2((target_y - y), (target_x - x));

        double alpha;
        if(angle_to_target >= 0 && angle_to_target < M_PI/2){
            alpha = angle_to_target; // 1
        }else if(angle_to_target >= M_PI/2){
            alpha = M_PI - angle_to_target; // 2
            speed = -speed;
            omega_flag = -1;
        }else if(angle_to_target < 0 && angle_to_target >= -M_PI/2){
            alpha = -angle_to_target; // 4
            omega_flag = -1;
        }else{
            alpha = M_PI + angle_to_target; // 3
            speed = -speed;
        }

        double r = distance/2/cos(M_PI/2-alpha);
        double omega = speed/r*omega_flag;            // angle_velocity_z

        // give command
        geometry_msgs::msg::Twist velocity_command;
        velocity_command.linear.x = speed;
        velocity_command.angular.z = omega;

        rclcpp::Rate rate(100); // 设置检查频率，这里每秒检查10次

        while (true)
        {
            distance = std::sqrt(std::pow((target_x - x), 2) + std::pow((target_y - y), 2));
            RCLCPP_INFO(this->get_logger(), "distance: %f", distance);
            cmd_pub_->publish(velocity_command);

            double x_fore = x+speed*cos(theta)*0.01;
            double y_fore = y+speed*sin(theta)*0.01;
            double distance_fore = std::sqrt(std::pow((target_x - x_fore), 2) + std::pow((target_y - y_fore), 2));

            if (distance < distance_fore && distance < 0.2){
                break;
            }
            rate.sleep();
        }
        // while(abs(x-target_x) > 1){
        //     RCLCPP_INFO(this->get_logger(), "x: %f, y: %f", x, y);
        //     rate.sleep();
        // }
        if (distance < 0.1){
            response->move_result = 1;
        }else{
            response->move_result = 0;
        }

        RCLCPP_INFO(this->get_logger(), "After movement, turtle current position - x: %f, y: %f", x, y);
        
        // 输出日志信息，提示已经完成加法求和计算                                                    
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Incoming request\na: %ld" " b: %ld",             
        //             request->a, request->b);
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "sending back response: [%ld]", (long int)response->sum);
    }
    private:
    rclcpp::Service<turtle_controller_interfaces::srv::Goto>::SharedPtr server_;
    rclcpp::CallbackGroup::SharedPtr callback_group;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr sub_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
    float x,y,theta;
    void pose_cb(const turtlesim::msg::Pose::SharedPtr pose)
    {
        x = pose->x;
        y = pose->y;
        theta = pose->theta;
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "%f",x);
    }
};

// float x_pos,y_pose,theta_pose;

// void gotoServer(const std::shared_ptr<turtle_controller_interfaces::srv::Goto::Request> request, 
//         std::shared_ptr<turtle_controller_interfaces::srv::Goto::Response>      response)
// {
//     RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Let's go!");
//     response->move_result = 1;
//     rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr sub_;
//     rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
//     // sub_ = create_subscription<turtlesim::msg::Pose>("/turtle1/pose", 10, std::bind(&gotoServer::pose_cb,this,std::placeholders::_1));
//     // cmd_pub_ = create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
// }

// ROS2节点主入口main函数
int main(int argc, char **argv)                                                                 
{
    // ROS2 C++接口初始化
    // rclcpp::init(argc, argv);
    // // 创建ROS2节点对象并进行初始化                                                                   
    // std::shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("gotoServer");   
    // // 创建服务器对象（接口类型、服务名、服务器回调函数）  
    // rclcpp::Service<turtle_controller_interfaces::srv::Goto>::SharedPtr service =
    //     node->create_service<turtle_controller_interfaces::srv::Goto>("goto", &gotoServer);
          
    // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Ready to move.");

    // // 循环等待ROS2退出
    // rclcpp::spin(node);    
    // // 关闭ROS2 C++接口                                                                     
    // rclcpp::shutdown();

    rclcpp::init(argc, argv);
    auto node = std::make_shared<gotoServer>();
    // 把节点的执行器变成多线程执行器, 避免死锁
    rclcpp::executors::MultiThreadedExecutor exector;
    exector.add_node(node);
    exector.spin();
    rclcpp::shutdown();

    return 0;                                          
}