#include "rclcpp/rclcpp.hpp"
#include "turtle_controller_interfaces/srv/goto.hpp"    // 自定义的服务接口
#include "turtle_controller_interfaces/srv/follow_path.hpp"    // 自定义的服务接口

using namespace std::chrono_literals;

using std::placeholders::_1;

//创建一个类节点，名字叫做Poorer,继承自Node.
class Poorer : public rclcpp::Node
{
public:
    // 构造函数
    Poorer() : Node("Poorer")
    {
        // 打印一句自我介绍
        RCLCPP_INFO(this->get_logger(), "I'm a cute turtle");
        // 实例化客户端, 指明客户端的接口类型，同时指定要请求的服务的名称Calculate.
        if (argc < 4) {
            RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "usage: turtle_move_client X Y SPEED or X_array Y_array SPEED");
            return 1;
        } elseif (argc == 4) {
            RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "goto");
            // 创建服务客户端对象（服务接口类型，服务名） 
            rclcpp::Client<turtle_controller_interfaces::srv::Goto>::SharedPtr client =
            node->create_client<turtle_controller_interfaces::srv::Goto>("goto"); 



        Poorer_Client = this->create_client<service_interfaces::srv::Calculate>("Calculate");
    }

    int take_hamburger(int argc, char **argv)
    {
        RCLCPP_INFO(this->get_logger(), "现在去领取汉堡");
        
        //构造请求
        auto request = std::make_shared<service_interfaces::srv::Calculate::Request>();
        
        //等待服务端上线
        while (!Poorer_Client->wait_for_service(1s))
        {
            //等待时检测rclcpp的状态
            if (!rclcpp::ok())
            {
                // 检测到Ctrl+C直接退出
                RCLCPP_ERROR(this->get_logger(), "等待被打断, 不等了");
                rclcpp::shutdown();
                return 1;
            }
            // 否则一直等
            RCLCPP_INFO(this->get_logger(), "等待热心组织开门");
        }

        // 输入参数格式错误的时候报错并退出程序
        if (argc != 3)
        {
            RCLCPP_ERROR(this->get_logger(), "输入格式错误, 格式为: 什么人 几口人. 例如: ros2 run poor_and_organization Poor_node Poorer 3");
            rclcpp::shutdown();
            return 1;
        }
        else
        {
            // 格式正确, 获取参数, 放入request中
            request->status =             argv[1];
            request->num_of_people = atoi(argv[2]);
            RCLCPP_INFO(this->get_logger(), "我是%s, 我家有%d个人", request->status.c_str(), request->num_of_people);
        }

        //发送异步请求，然后等待返回，返回时调用回调函数
        Poorer_Client->async_send_request(request, std::bind(&Poorer::poorer_callback, this, _1));

        return 0;
    }
private:
    // 创建一个客户端
    rclcpp::Client<service_interfaces::srv::Calculate>::SharedPtr Poorer_Client;

    // Input num
    int input_num = argc;

    // 创建接收到小说的回调函数
    void poorer_callback(rclcpp::Client<service_interfaces::srv::Calculate>::SharedFuture response)
    {
        // 使用response的get()获取
        auto result = response.get();
        // 如果确实是Poorer, 则领取成功
        if(result->success == true)
        {
            RCLCPP_INFO(this->get_logger(), "成功领取%d个汉堡", result->num_of_hamburger);
            rclcpp::shutdown();
        }
        // 不是Poorer或者汉堡数量不够, 则领取失败
        else
        {
            RCLCPP_INFO(this->get_logger(), "领取汉堡失败, 原因可能为: 1.你不是Poorer 2.汉堡不够了");
            rclcpp::shutdown();
        }
    }
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    // 产生一个Poorer的节点
    auto node = std::make_shared<Poorer>();
    node->take_hamburger(argc, argv);
    // 运行节点，并检测rclcpp状态
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
